﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HangmanQuiz.Helpers
{
        public enum CategoryName
        {
            IT = 1,
            Countries = 2,
            Food = 3
        };
}
