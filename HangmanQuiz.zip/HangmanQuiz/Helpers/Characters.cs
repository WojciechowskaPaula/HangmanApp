﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HangmanQuiz.Helpers
{
    public static class Characters
    {
        public static char Underscore = '_';
        public static char WhiteSpace = ' ';
    }
}
